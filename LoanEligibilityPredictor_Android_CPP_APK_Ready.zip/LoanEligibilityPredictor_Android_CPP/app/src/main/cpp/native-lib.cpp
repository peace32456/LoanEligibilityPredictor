#include <jni.h>
#include <cmath>
#include <string>

static double sigmoid(double z) { return 1.0 / (1.0 + std::exp(-z)); }
static int eq(const char* a, const char* b) { return std::string(a) == b; }

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_loaneligibilitypredictor_MainActivity_predictNative(
        JNIEnv* env, jobject,
        jstring gender_, jstring married_, jstring dependents_, jstring education_,
        jstring selfEmployed_, double applicantIncome, double coapplicantIncome,
        double loanAmount, double loanTerm, double creditHistory, jstring propertyArea_) {

    const char *gender = env->GetStringUTFChars(gender_, nullptr);
    const char *married = env->GetStringUTFChars(married_, nullptr);
    const char *dependents = env->GetStringUTFChars(dependents_, nullptr);
    const char *education = env->GetStringUTFChars(education_, nullptr);
    const char *selfEmployed = env->GetStringUTFChars(selfEmployed_, nullptr);
    const char *propertyArea = env->GetStringUTFChars(propertyArea_, nullptr);

    // Coefficients exported from the project's LogisticRegression pipeline.
    double z = 1.7692514822374064;
    if (eq(gender,"Female")) z += -0.12185532; else z += 0.12146174;
    if (eq(married,"No")) z += -0.48371129; else z += 0.48331772;
    if (eq(dependents,"0")) z += 0.10094932;
    else if (eq(dependents,"1")) z += -0.25040378;
    else if (eq(dependents,"2")) z += 0.34300935;
    else z += -0.19394846;
    if (eq(education,"Graduate")) z += 0.78088791; else z += -0.78128148;
    if (eq(selfEmployed,"No")) z += 0.64079643; else z += -0.64119001;
    if (eq(propertyArea,"Rural")) z += -0.34296716;
    else if (eq(propertyArea,"Semiurban")) z += 0.35567543;
    else z += -0.01310184;

    // StandardScaler means/scales from the same training pipeline.
    z += 0.40967012 * ((applicantIncome - 83981.22916666667) / 38883.58377451294);
    z += 0.13425360 * ((coapplicantIncome - 39045.48229166667) / 23647.872862314412);
    z += -0.83203733 * ((loanAmount - 518105.77395833336) / 270718.87995928613);
    z += -0.08514334 * ((loanTerm - 239.875) / 83.15638505250213);
    z += 1.57415884 * ((creditHistory - 0.859375) / 0.3476343040826092);

    double probability = sigmoid(z);
    int eligible = probability >= 0.5 ? 1 : 0;
    char out[256];
    snprintf(out, sizeof(out), "%d|%.4f", eligible, probability);

    env->ReleaseStringUTFChars(gender_, gender);
    env->ReleaseStringUTFChars(married_, married);
    env->ReleaseStringUTFChars(dependents_, dependents);
    env->ReleaseStringUTFChars(education_, education);
    env->ReleaseStringUTFChars(selfEmployed_, selfEmployed);
    env->ReleaseStringUTFChars(propertyArea_, propertyArea);
    return env->NewStringUTF(out);
}
