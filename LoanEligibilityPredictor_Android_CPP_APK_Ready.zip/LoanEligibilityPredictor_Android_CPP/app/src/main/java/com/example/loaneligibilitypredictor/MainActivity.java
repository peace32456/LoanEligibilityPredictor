package com.example.loaneligibilitypredictor;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.Context;

public class MainActivity extends Activity {
    static { System.loadLibrary("native-lib"); }
    private native String predictNative(String gender, String married, String dependents, String education,
        String selfEmployed, double applicantIncome, double coapplicantIncome, double loanAmount,
        double loanTerm, double creditHistory, String propertyArea);

    private EditText income, coIncome, loanAmount;
    private Spinner gender, married, dependents, education, selfEmployed, loanTerm, creditHistory, propertyArea;
    private TextView result;

    String[] genders={"Male","Female"}, marriedVals={"Yes","No"}, deps={"0","1","2","3+"}, edu={"Graduate","Not Graduate"};
    String[] selfVals={"No","Yes"}, terms={"120","180","240","300","360"}, credit={"Good (1)","Poor (0)"}, areas={"Urban","Semiurban","Rural"};

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUI(); }
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(35,35,35)); return t; }
    Spinner spin(String[] a){ Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a)); return s; }
    EditText num(String hint,String value){ EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setInputType(2|8192); e.setPadding(18,10,18,10); return e; }
    void add(LinearLayout box, String label, View v){ TextView l=tv(label,14); l.setTypeface(Typeface.DEFAULT,Typeface.BOLD); box.addView(l); box.addView(v); box.addView(new Space(this),new LinearLayout.LayoutParams(1,10)); }

    void buildUI(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,24,28,30); root.setBackgroundColor(Color.rgb(248,250,252)); scroll.addView(root); setContentView(scroll);
        TextView title=tv("Loan Eligibility Predictor",27); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setTextColor(Color.rgb(21,101,192)); root.addView(title);
        TextView sub=tv("Machine Learning • FinTech Academic Project",14); root.addView(sub); root.addView(new Space(this),new LinearLayout.LayoutParams(1,20));
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(20,20,20,20); card.setBackgroundColor(Color.WHITE); root.addView(card);
        gender=spin(genders); married=spin(marriedVals); dependents=spin(deps); education=spin(edu); selfEmployed=spin(selfVals); loanTerm=spin(terms); creditHistory=spin(credit); propertyArea=spin(areas);
        income=num("Monthly income","50000"); coIncome=num("Monthly co-applicant income","0"); loanAmount=num("Loan amount","300000");
        add(card,"Gender",gender); add(card,"Married",married); add(card,"Dependents",dependents); add(card,"Education",education); add(card,"Self Employed",selfEmployed);
        add(card,"Applicant Income (₹ / month)",income); add(card,"Coapplicant Income (₹ / month)",coIncome); add(card,"Loan Amount (₹)",loanAmount); add(card,"Loan Term (months)",loanTerm); add(card,"Credit History",creditHistory); add(card,"Property Area",propertyArea);
        Button predict=new Button(this); predict.setText("PREDICT ELIGIBILITY"); predict.setTextColor(Color.WHITE); predict.setBackgroundColor(Color.rgb(21,101,192)); card.addView(predict);
        result=tv("",18); result.setGravity(Gravity.CENTER); result.setPadding(8,24,8,16); card.addView(result);
        TextView about=tv("Educational project only. This prediction is not an official banking or lending decision.\n\nModel: Logistic Regression\nTraining split: 80/20\nDataset: synthetic educational data",13); about.setTextColor(Color.DKGRAY); root.addView(about);
        predict.setOnClickListener(v -> runPrediction());
    }
    double val(EditText e){ try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;} }
    void runPrediction(){
        if(income.getText().toString().trim().isEmpty()||coIncome.getText().toString().trim().isEmpty()||loanAmount.getText().toString().trim().isEmpty()){ result.setText("Please enter all numeric values."); return; }
        String r=predictNative(gender.getSelectedItem().toString(),married.getSelectedItem().toString(),dependents.getSelectedItem().toString(),education.getSelectedItem().toString(),selfEmployed.getSelectedItem().toString(),val(income),val(coIncome),val(loanAmount),Double.parseDouble(loanTerm.getSelectedItem().toString()),creditHistory.getSelectedItemPosition()==0?1.0:0.0,propertyArea.getSelectedItem().toString());
        String[] p=r.split("\\|"); boolean ok=p[0].equals("1"); double prob=Double.parseDouble(p[1])*100.0;
        result.setText((ok?"PRELIMINARY RESULT: LOAN ELIGIBLE":"PRELIMINARY RESULT: LOAN NOT ELIGIBLE")+"\n\nModel probability: "+String.format("%.2f",prob)+"%"); result.setTextColor(ok?Color.rgb(27,110,55):Color.rgb(183,28,28)); result.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    }
}
