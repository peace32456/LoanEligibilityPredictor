# Loan Eligibility Predictor — Android C++/NDK App

This is the mobile version of the Loan Eligibility Predictor academic project. It is an Android Studio project with the prediction engine implemented in C++ using the Android NDK/JNI. The UI is native Android Java, while the Logistic Regression calculation runs in `native-lib.cpp`.

## Build APK
1. Open this folder in Android Studio.
2. Install Android SDK 35, NDK and CMake 3.22.1 from SDK Manager.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled or start an emulator.
5. Select **Build > Build APK(s)**.
6. Install the generated debug APK from `app/build/outputs/apk/debug/`.

## Project model
- Algorithm: Logistic Regression
- Train/Test split: 80/20
- Random state: 42
- Dataset: synthetic educational dataset
- Test accuracy from the original Python training project: 92.92%

The C++ coefficients and StandardScaler values are embedded from the same trained pipeline, so the mobile app performs the prediction locally without a web server.

## Important
This is an academic demonstration and not a real banking/lending decision system.
